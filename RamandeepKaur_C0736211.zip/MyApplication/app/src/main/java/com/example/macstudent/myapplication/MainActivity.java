package com.example.macstudent.myapplication;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.seismic.ShakeDetector;

import java.io.IOException;

public class MainActivity extends AppCompatActivity implements ShakeDetector.Listener{

    // global variable to track if light is on/off
    boolean lightOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. create a bunch of nonsense variables
        // that are used to detect when the phone is shaking
        // (setup your phone to deal with shakes)
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);
    }

    // this a mandatory function
    // it's required by the ShakeDetector.Listener class
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override public void hearShake() {

        // 2. this function AUTOMAGICALLY gets called
        // every time you shake the phone

        // print out a message when the phone shakes
        Log.d("JENELLE", "phone is shaking!!!!");
        Toast.makeText(this, "PHONE IS SHAKING!!!!", Toast.LENGTH_SHORT).show();

        // Check for permissions
        if (Build.VERSION.SDK_INT < 23) {
            // Person is using an old version of Android. Y
            // Just go to the photo gallery.
            getPhotoFromGallery();
        }
        else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                // Person did NOT give permission, so start the process of asking for permission

                // You can choose ANY request code
                // It's just a random number that YOU choose
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 123);

            } else {
                // Person previously gave permission to your app, so
                // directly go to the gallery
                getPhotoFromGallery();

            }
        }
       
   }


    public void getPhotoFromGallery() {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        // Remember: Choose any number for the request code!
        startActivityForResult(i, 123);
    }




    // Function for showing the permission popup box.
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // This request code should match the number you chose in the .requestPermissions(...) function.
        if (requestCode == 123) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getPhotoFromGallery();
            }
        }

    }


    // After the user selects a photo, run this code
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // This function will run anytime an Activity closes.
        // The only way for your code to tell the difference between the Activities is
        // through the REQUESTCODE.  Every Activity should have a different code!
        if (requestCode == 123 && resultCode == RESULT_OK && data != null) {

            Uri imageFromGallery = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageFromGallery);
                ImageView imageView = (ImageView) findViewById(R.id.thePhoto);
                imageView.setImageBitmap(bitmap);

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}
